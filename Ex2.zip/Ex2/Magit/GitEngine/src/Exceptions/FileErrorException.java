package Exceptions;

public class FileErrorException extends Exception {
    public FileErrorException(String errorMessage) {
        super(errorMessage);
    }
}
