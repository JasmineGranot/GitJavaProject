package MagitMain;

//public class MagitMain {
//    public static void main(String[] args){
//        UI uiConsole = new UI();
//        uiConsole.runProgram();
//    }
//}
