package GitObjects;

public class Sha1Obj {
    public String sha1String = "";
}

